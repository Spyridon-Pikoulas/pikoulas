# PrintFill three-row starter

All values are synthetic. `labels.csv` is UTF-8. QRPayload contains two example.com links and
one Greek text payload. BarcodeValue contains separate printable ASCII identifiers with leading
zeros; do not map the Greek payload column to Code 128.

## Import without losing zeros

In Google Sheets, choose **File → Import → Upload** and select `labels.csv`. Insert a new sheet,
choose the comma separator, and **turn off “Convert text to numbers, dates, and formulas” before
importing**. Check that BarcodeValue displays `00001`, `00002`, `00003` and that the Greek text
is readable. If an import removed zeros, undo/reimport with conversion off; formatting a number
as text afterwards cannot restore them. Keep the heading row.

## Preview, then generate

1. Select `A1:D4`. Open PrintFill, confirm the displayed Google account, choose selected cells,
   enable headings and click **Load displayed rows**.
2. Map **Filename ID** to FilenameID (A), **Caption** to Caption (D).
3. For QR, choose **QR - UTF-8 text or URL** and map **Payload column** to QRPayload (B).
   For Code 128, choose **Code 128 - printable ASCII** and map Payload column to BarcodeValue (C).
4. Choose **FS21 - A4, 21 labels** or **OL875 supplier PDF - Letter, 30 labels**, matching your
   exact stock. Start at slot 1 on an unused sheet. Click **Preview all rows - free** and review
   the prepared PDF, then confirm the whole batch and displayed account.
5. Click **Generate PDF + PNG ZIP**, then **Download ZIP**. The output contains `labels.pdf`,
   `sample-00001.png` through `sample-00003.png`, and `manifest.json` with the mapped raw values.

Preview is free. Your first generated three-row job uses **3 of 12 free row-codes total per
Google account**. Generating these rows again in a **different code format or other different
job uses another 3**; QR plus Code 128 is 6, not 3. A recognized retry of the same unchanged
latest job or repeated download does not count again. Authorizing a different job replaces that
latest retry record. A batch larger than the remaining allowance is refused as a whole; select
fewer rows or unlock for $9 once. No subscription.

## Check before printing

Print at **Actual size / 100%** on matching A4 or Letter paper. Test on plain paper and compare
with the actual stock, then check your printed codes with your own scanner. These exact layouts
follow FS21 supplier dimensions and OL875 supplier PDF outlines; other stock is not promised to
align. Digital checks do not certify any printer, scanner, GS1 or retail use. Supplier names/code
references identify layouts; PrintFill is independent and not endorsed by those suppliers.

The renderer has digitally checked these exact three rows in both code formats, including
leading-zero bytes and Greek QR/captions. This is not a physical print test.

QR Code is a registered trademark of DENSO WAVE INCORPORATED. Google Sheets is a trademark of
Google LLC.
