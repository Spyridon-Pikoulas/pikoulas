# Try a manually colored table

Unzip this download, then import `colorsum-example.xlsx` into Google Sheets. For example, in a
new blank spreadsheet choose **File > Import > Upload**, select the XLSX, and insert its sheet.
Use a new file or new tab so an existing table is not replaced.

1. Open the **Expenses** tab. Select just **B2:B5**, the four amounts, without the heading.
2. Open **Extensions > ColorSum > Open ColorSum**. Install ColorSum from
   https://pikoulas.com/colorsum/ first if needed.
3. Keep **Fill color** selected and click **Count the selected cells** once.

Expected sidebar results:

| Manual fill | Cells | Sum | Average |
| --- | ---: | ---: | ---: |
| Pink (`#f4cccc`) | 3 | 35 | 11.67 |
| Green (`#d9ead3`) | 1 | 7 | 7 |

This is one Free sidebar count, from the normal allowance of ten counts a day. You do not need
Pro, a trial, formula insertion or automatic refresh to try it. A sidebar result is a snapshot:
count again after editing values or colors; another Count uses another daily count.

The colors were applied by hand. There are no formulas or conditional-formatting rules in the
file. Changing a Status value does not repaint its amount. If your colors come from a status
rule, use the values instead: `=COUNTIF(A2:A5,"Queued")` gives 3 and
`=SUMIF(A2:A5,"Queued",B2:B5)` gives 35 without an add-on. Those formulas follow the status values,
not the pink paint. More: https://pikoulas.com/colorsum/

The data is synthetic. You can edit it or delete the example tab when finished.
