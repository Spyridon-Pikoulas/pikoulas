# PacketFill starter example

This ZIP contains an original blank workshop-registration PDF and three fictional CSV records.
It does not register anyone or send email. The form was created by Spyridon Pikoulas for
PacketFill demonstrations and is provided for use and adaptation with this example.

## Import without losing identifiers

1. Extract the ZIP. In an empty Google Sheets spreadsheet, choose **File > Import > Upload**
   and select `rows.csv`.
2. Choose **Insert new sheet(s)** and comma as the separator. Turn OFF **Convert text to
   numbers, dates, and formulas**, then import. Keep the imported data starting at A1.
3. Check that C2 displays `00042`, C3 `00007`, and C4 `00123`. Dates must display eight digits,
   for example `20261018`, not a localized date. Quoting a CSV value alone does not prevent
   number conversion. If zeros disappeared, import again with conversion off before continuing.

The CSV is UTF-8; names include accented Latin and Greek. Its identifiers and dates are text,
not numbers to calculate. `Agree` uses explicit TRUE/FALSE text, which PacketFill accepts as
checkbox values; a blank clears the checkbox. Do not convert these cells to Yes/No.

## Preview one record first

Open PacketFill from **Extensions > PacketFill > Open PacketFill** after installing it from
https://pikoulas.com/packetfill/. Check the displayed Google account.

For the initial test, select **A1:G2 only**: the header and first record. Choose **Selected
cells**, leave **First row contains column headings** checked, and click **Load displayed rows**.
Do not use the entire tab for this first generation.

Choose the local `workshop-registration.pdf`. Map the named PDF fields to these source columns:

| PDF field | Source heading (column) |
| --- | --- |
| Name | Name (B) |
| Identifier | Identifier (C) |
| Agree | Agree (D) |
| Nationality | Nationality (E) |
| Radio | Radio (F) |
| Date | Date (G) |

Use **RecordId (A)** for the filename, **9 pt** for text, and **Clear existing values** for
**Unmapped editable fields**.
Nationality must be exactly `French`, `German` or `Unknown`. Radio uses the export values `1`
or `2`, rather than the printed captions Group 1/Group 2; blank clears the selection. Date is
the eight-character YYYYMMDD value for the PDF's eight comb boxes. Keep/Clear affects unmapped
fields; a mapped blank clears that field.

Click **Check all rows and preview**. Check the actual page: Zoë García, identifier `00042`,
date `20261018`, French, Group 1 and the checked attendance box. Preview is free. If it reports
an error, fix the selection/mapping before generating.

## Generate deliberately

PacketFill includes **three generated PDFs free in total per Google account**, then **$9 once**.
This is not a daily allowance. Each selected record produces one PDF; its page count does not
change that count. Generating all three example records uses all three free outputs if they
remain. Preview alone uses none.

For the initial test, confirm that only **one record** is loaded, check the confirmation and
click **Generate ZIP download**. Save the ZIP through its download link and open the completed
PDF. It is static/flattened, not an editable form. A successful generation counts when its
completion is recorded, even if the later save fails; **Download ZIP again** recovers the same
open result. The latest unchanged job can also retry after reopening and reselecting the same
PDF, source and settings. Different jobs replace that retry history.

To try the other records later, explicitly select the rows you want with their headings, load
again and preview. The whole selected batch must fit the remaining allowance; PacketFill does
not silently generate just the first free records. Use a smaller selection or unlock when needed.
