# Try EventFill's Check rows

Unzip this download, then import `eventfill-example.xlsx` into Google Sheets. In a new blank
spreadsheet choose **File > Import > Upload**, select the XLSX and insert its sheet. Use a new
file or new tab so an existing schedule is not replaced. Open the **Practice** tab.

1. Check **File > Settings > Time zone**. Choose **UTC** for the example below, save and reload.
   XLSX files do not set a Google spreadsheet's time zone. For your own schedule, use its intended
   zone; EventFill interprets times in that spreadsheet zone, while Calendar may display another.
2. Install EventFill from https://pikoulas.com/eventfill/ if needed. Open **Extensions > EventFill
   > Open EventFill**, then **Use the current sheet**. Check the Google account shown.
3. Map Title → **Title**, Start date → **Start date**, Start time → **Start time**, End time →
   **End time**, Location → **Location**. Leave End date, Description, Guests and Color unmapped.
4. Click **Check rows**. Expect **2 valid rows, 0 errors and 0 empty rows**. Stop there: checking
   creates no Calendar events, changes no source cells and uses none of the free allowance.
   This exercise does not require Add to Calendar, a paid plan or a trial.

| Source row | Example | Expected interpretation with spreadsheet zone UTC |
| --- | --- | --- |
| 2 | Practice session | 3 November 2026, 10:00–11:00 UTC |
| 3 | Practice day | All day on 4 November 2026; exclusive end 5 November |

The dates and times are typed spreadsheet values with `yyyy-mm-dd` and `hh:mm` formats, not
ambiguous date text. Both time cells on row 3 are genuinely blank, which makes that row all-day.
Do not enter 00:00 there to mean “no time”. The file has no formulas, guests, Calendar IDs or
event links. These practice rows are synthetic.

Two valid rows mean their date/time inputs parse. They do not establish Calendar permissions,
service-quota availability or successful event creation. If you later deliberately choose Add
to Calendar, the two unlinked rows create two real events and use the normal allowance.

For a one-off Calendar transfer you may not need an add-on. Google's free CSV/ICS import uses
different headers: https://support.google.com/calendar/answer/37118?hl=en . This XLSX is for
EventFill, not a Calendar CSV file. More: https://pikoulas.com/eventfill/
