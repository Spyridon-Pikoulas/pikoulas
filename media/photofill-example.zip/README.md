# PhotoFill local-image starter

Two original synthetic PNGs: 01-ochre.png and 02-teal.png. Unzip this download first.
No personal photos, account files or image dates are included.

1. Install PhotoFill from https://pikoulas.com/photofill/ and open a presentation.
   Keep its existing slides. Open Extensions > PhotoFill > Open PhotoFill and check
   the Google account shown in the sidebar.
2. Under "Or select local JPEG / PNG files", select BOTH PNGs from this folder.
3. Use "As selected / manual order" and the earlier/later arrows to put 02-teal.png
   BEFORE 01-ochre.png. Choose "Two per slide", "Caption: None" and a white background.
   Check the preview: 02 teal on the LEFT, 01 ochre on the RIGHT.
4. Check that the remaining allowance covers two images. Click the import action
   labelled with your account ONCE and wait for completion.

Expected result: ONE NEW slide after your current slide, with 02 teal on the LEFT
and 01 ochre on the RIGHT. Existing slides stay in place. Previewing adds no slides
and uses no image allowance. A successful import of this pair uses two insertions.
Local files provide no photo dates; use manual or filename order.

If the outcome is unclear, reopen PhotoFill in the SAME presentation and check its
saved job before starting another import. For local-file recovery after browser
closure, select these same original PNGs again; do not launch a duplicate job.

New users get 12 successful photo insertions free in total; users who already had
the 30/day allowance keep it. A $4.99 seven-day pass does not renew. Current plans and help:
https://pikoulas.com/photofill/
https://pikoulas.com/photofill/upload-multiple-images-google-slides/

Watch these exact images, order and layout in the actual local-file tutorial:
https://youtu.be/-NrXkEsJo3E

For a few pictures, Google Slides also offers Insert > Image > Upload from computer;
you can add and arrange the images yourself without PhotoFill.

These synthetic images are by Pikoulas and may be used to try PhotoFill or native
Google Slides image insertion. Google Slides is a trademark of Google LLC.
PhotoFill is independent and is not endorsed by Google.
